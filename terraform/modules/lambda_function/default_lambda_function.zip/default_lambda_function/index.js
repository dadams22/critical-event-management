throw new Error( 'No lambda function uploaded' );
